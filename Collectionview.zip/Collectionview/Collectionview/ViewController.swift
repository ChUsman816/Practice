//
//  ViewController.swift
//  Collectionview
//
//  Created by Ninesol Tech RN on 15/01/2023.
//

import UIKit
import Photos

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var tableViewHeight = [70,70,70,70,70,70]
    var albumRecords = [albumData]()
    var isAppRun = true
    var dataType = 0 // 0 = photo , 1 = video, 2 = audio , 3 = files
    var selectedValueForAllIndex = [Bool]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        fetchPhotosAndData ()
      
    }
    
    func getPhotoAccess(completionHandler: @escaping(Bool)->()){
        // 1
        guard PHPhotoLibrary.authorizationStatus() != .authorized else {
            completionHandler(true)
            return
        }
        // 2
        PHPhotoLibrary.requestAuthorization { status in
            if status == .authorized {
                completionHandler(true)
            }
            else{
                completionHandler(false)
            }
            return
        }
    }
    
    func fetchPhotosAndData (){
        getPhotoAccess { permission in
            if permission {
                if self.isAppRun {
                    if CustomPhotoAlbum.sharedInstance.fetchAssetCollectionForAlbum() == nil {
                        CustomPhotoAlbum.sharedInstance.createAlbum()
                    }
                    self.isAppRun=false
                }
                DispatchQueue.main.async {
                    let onlyVideoOptions = PHFetchOptions()
                    onlyVideoOptions.sortDescriptors = [
                        NSSortDescriptor(
                            key: "creationDate",
                            ascending: false)
                    ]
                    onlyVideoOptions.predicate = NSPredicate(format: "mediaType = %d", PHAssetMediaType.video.rawValue)
                        //self.videos = PHAsset.fetchAssets(with: onlyVideoOptions)
                    // 1
                    let onlyPhotosOptions = PHFetchOptions()
                    onlyPhotosOptions.sortDescriptors = [
                        NSSortDescriptor(
                            key: "creationDate",
                            ascending: false)
                    ]
                    onlyPhotosOptions.predicate = NSPredicate(format: "mediaType = %d", PHAssetMediaType.image.rawValue)
                    // 2
                    let smartAlbums = PHAssetCollection.fetchAssetCollections(
                        with: .smartAlbum,
                        subtype: .any,
                        options: nil)
                    let topLevelUserCollections = PHCollectionList.fetchTopLevelUserCollections(with: nil)
                    self.albumRecords.removeAll()
                    for ind in 0..<smartAlbums.count {
                        let collection = smartAlbums[ind]
                        let fetchedAssets = PHAsset.fetchAssets(in: collection, options: onlyPhotosOptions)
                        if fetchedAssets.count > 0 && collection.localizedTitle != "Recently Deleted" {
                            self.albumRecords.append(albumData(name: collection.localizedTitle!, albumAssest: fetchedAssets))
                        }
                    }
                    
                    
                    for ind in 0..<topLevelUserCollections.count {
                        if let collection = topLevelUserCollections[ind] as? PHAssetCollection {
                            let fetchedAssets = PHAsset.fetchAssets(in: collection, options: onlyPhotosOptions)
                            if fetchedAssets.count > 0 {
                                self.albumRecords.append(albumData(name: collection.localizedTitle!, albumAssest: fetchedAssets))
                            }
                        }
                    }
                }
            }
            //When Photos PopUp hide then this code run
            DispatchQueue.main.async {
                // FetchingAudio
//                let mPMediaQuery = MPMediaQuery.songs()
//                self.audioAssetFromMob.removeAll()
//                if let collections = mPMediaQuery.collections {
//                    for collection in collections {
//                        self.audioAssetFromMob += collection.items
//                    }
//                }
           //     self.audioAssetFromApp = DBManager.shared.getAudioFiles()
                //MARK: Checking if file deleted by user from Phone Files App
//                for audioAsset in self.audioAssetFromApp {
//                    let directory = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last! as URL
//                    let filePath = directory.appendingPathComponent(audioAsset.fileUrl)
//                    do {
//                        let _ = try Data(contentsOf: filePath)
//                    } catch {
//                        if let ind = self.audioAssetFromApp.firstIndex(where: {$0.fileUrl == audioAsset.fileUrl }){
//                            self.audioAssetFromApp.remove(at: ind)
//                        }
//                    }
//                }
//                DBManager.shared.saveAudioFiles(fileData: self.audioAssetFromApp)
//                self.documentFiles = DBManager.shared.getDocumentFiles()
//                //MARK: Checking if file deleted by user from Phone Files App
//                for docAsset in self.documentFiles {
//                    let directory = (FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)).last! as URL
//                    let filePath = directory.appendingPathComponent(docAsset.fileUrl)
//                    do {
//                        let _ = try Data(contentsOf: filePath)
//                    } catch {
//                        if let ind = self.documentFiles.firstIndex(where: {$0.fileUrl == docAsset.fileUrl }){
//                            self.documentFiles.remove(at: ind)
//                        }
//                    }
//                }
//                DBManager.shared.saveDocumentFiles(fileData: self.documentFiles)
                
                
           //     self.quickLookController.reloadData()
                
                switch self.dataType {
                case 0 :
                    self.selectedValueForAllIndex = [Bool](repeating: false, count: self.albumRecords.count)
                case 1:
                  //  self.selectedValueForAllIndex = [Bool](repeating: false, count: self.videos.count)
                    break
                    
                case 2:
                    //self.selectedValueForAllIndex = [Bool](repeating: false, count: self.audioAssetFromMob.count+self.audioAssetFromApp.count)
                    break
                default:
                    //elf.selectedValueForAllIndex = [Bool](repeating: false, count: self.documentFiles.count)
                    break
                }
           //     self.hideShowEmptyListView()
                
                self.tableViewHeight.removeAll()
                for i in self.albumRecords
                {
                    self.tableViewHeight.append(70)
                }
                self.tableView.reloadData()
            }
        }
    }


}


extension ViewController:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return albumRecords.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCell
        cell.lbl.text = albumRecords[indexPath.row].name
        cell.photoAlbumDetail.albumAssest = albumRecords[indexPath.row].albumAssest
        cell.collectionview.reloadData()
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(tableViewHeight[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableViewHeight[indexPath.row] == 80
        {
            self.tableViewHeight[indexPath.row] = 230
            self.tableView.reloadData()
        }else{
            self.tableViewHeight[indexPath.row] = 80
            self.tableView.reloadData()
        }
    }
    
    
    
}



struct albumData {
    var name : String!
    var albumAssest = PHFetchResult<PHAsset>()
}


class CustomPhotoAlbum: NSObject {
    
    static let albumName = "File Sharing"
    static let sharedInstance = CustomPhotoAlbum()
    
    var assetCollection: PHAssetCollection!
    
    override init() {
        super.init()
        
        if let assetCollection = fetchAssetCollectionForAlbum() {
            self.assetCollection = assetCollection
            return
        }
        //            else{
        //                createAlbum()
        //            }
    }
    
    func requestAuthorizationHandler(status: PHAuthorizationStatus) {
        if PHPhotoLibrary.authorizationStatus() == PHAuthorizationStatus.authorized {
            // ideally this ensures the creation of the photo album even if authorization wasn't prompted till after init was done
            print("trying again to create the album")
            self.createAlbum()
        } else {
            print("should really prompt the user to let them know it's failed")
        }
    }
    
    func createAlbum() {
        PHPhotoLibrary.shared().performChanges({
            PHAssetCollectionChangeRequest.creationRequestForAssetCollection(withTitle: CustomPhotoAlbum.albumName)   // create an asset collection with the album name
        }) { success, error in
            if success {
                self.assetCollection = self.fetchAssetCollectionForAlbum()
            } else {
                print("error \(String(describing: error))")
            }
        }
    }
    
    func fetchAssetCollectionForAlbum() -> PHAssetCollection? {
        let fetchOptions = PHFetchOptions()
        fetchOptions.predicate = NSPredicate(format: "title = %@", CustomPhotoAlbum.albumName)
        let collection = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: fetchOptions)
        
        if let _: AnyObject = collection.firstObject {
            return collection.firstObject
        }
        return nil
    }
    
    func save(image: UIImage , completion : @escaping () -> ()) {
        if assetCollection == nil {
            //            return                          // if there was an error upstream, skip the save
            if let assetCollection = fetchAssetCollectionForAlbum() {
                self.assetCollection = assetCollection
            }else{
                createAlbum()
            }
        }
        PHPhotoLibrary.shared().performChanges({
            let assetChangeRequest = PHAssetChangeRequest.creationRequestForAsset(from: image)
            let assetPlaceHolder = assetChangeRequest.placeholderForCreatedAsset
            let albumChangeRequest = PHAssetCollectionChangeRequest(for: self.assetCollection)
            let enumeration: NSArray = [assetPlaceHolder!]
            
            if self.assetCollection.estimatedAssetCount == 0
            {
                albumChangeRequest!.addAssets(enumeration)
            }
            else {
                albumChangeRequest!.insertAssets(enumeration, at: [0])
            }
            
        }, completionHandler: { status , errror in
            completion()
        })
    }
    func saveVideo(video:Data ,completion : @escaping () -> ()){
        //        let assetChangeRequest = PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: <#T##URL#>)
    }
    
    func getAudio()
    {
        var filePath = Bundle.main.path(forResource: "1", ofType: "mp3")
                           //transforming it to url
               var fileUrl = NSURL(fileURLWithPath: filePath!)
                           //instanciating asset with url associated file
        let asset = AVAsset(url: fileUrl as URL)
                        let metaData = asset.metadata
                        // print("metaData:", metaData.description)
                        // print("=====================================================================")
//                        if let artist = metaData.first(where: {$0.commonKey == .commonKeyArtist}), let value = artist.value as? String {
//                          var   artistName = value
//                           var artistList.append(artistName)
//                            // print("Artist:",artistName)
//                        }
//
//                        if let album = metaData.first(where: {$0.commonKey == .commonKeyAlbumName}), let value = album.value as? String {
//                            albumName = value
//                            // print("Album:",albumName)
//                        }

                        if let albumImage = metaData.first(where: {$0.commonKey == .commonKeyArtwork}), let value = albumImage.value as? Data {
                            let image = UIImage(data: value)
//                            img.image = image
//                            artWorkList.append(albumArtWork!)
                        } else {
                            print("artWork is not found!")
                        }
               
    }
}
