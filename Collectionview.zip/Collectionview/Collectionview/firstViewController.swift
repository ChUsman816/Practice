//
//  firstViewController.swift
//  Collectionview
//
//  Created by Ninesol Tech RN on 21/01/2023.
//

import UIKit
import AVFoundation
import MobileCoreServices
import PhotosUI
import MultipeerConnectivity

class firstViewController: UIViewController {
    
    
    
    @IBOutlet weak var img: UIImageView!
    
    var DeviceName : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DeviceName = UIDevice.current.name
        mpcHandler.setupPeerWithDisplayName(displayName: UIDevice.current.name)
        mpcHandler.setupSession()
        mpcHandler.advertiseSelf(advertise: true)
        mpcHandler.delegate = self
        
        
    }
    
    @IBAction func connectAction(_ sender: UIButton) {
        
        guard mpcHandler.session != nil else { return }
        mpcHandler.setupBrowser()
        mpcHandler.browser.delegate = self
        self.present(mpcHandler.browser, animated: true, completion: nil)
    }
    
}
extension firstViewController : MPCHandlerDelegate ,MCBrowserViewControllerDelegate {
    
    //Delegate Functions
    func changed(state: MCSessionState, of peer: MCPeerID) {
        guard state == .connected else {
            navigationItem.title = "No Connection"
            navigationItem.leftBarButtonItem?.isEnabled = true
            mpcHandler.advertiseSelf(advertise: true)
            return
        }
        navigationItem.title = "Connected"
        navigationItem.leftBarButtonItem?.isEnabled = false
        mpcHandler.advertiseSelf(advertise: false)
    }
    
    func received(data: Data, from peer: MCPeerID) {
        print(data)
        print(peer)
    }
    
    //Browser Functions
    func browserViewControllerDidFinish(_ browserViewController: MCBrowserViewController) {
        mpcHandler.browser.dismiss(animated: true, completion: nil)
    }
    
    func browserViewControllerWasCancelled(_ browserViewController: MCBrowserViewController) {
        mpcHandler.browser.dismiss(animated: true, completion: nil)

    }
    
    
}
