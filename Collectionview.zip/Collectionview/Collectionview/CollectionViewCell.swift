//
//  CollectionViewCell.swift
//  Collectionview
//
//  Created by Ninesol Tech RN on 15/01/2023.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var img: UIImageView!
}
