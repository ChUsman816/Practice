//
//  TableViewCell.swift
//  Collectionview
//
//  Created by Ninesol Tech RN on 15/01/2023.
//

import UIKit
import Photos

class TableViewCell: UITableViewCell {

    @IBOutlet weak var collectionview: UICollectionView!
    @IBOutlet weak var btn: UIButton!
    var photoAlbumDetail = albumData()

    @IBOutlet weak var lbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionview.delegate = self
        collectionview.dataSource = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}


extension TableViewCell:UICollectionViewDelegate,UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photoAlbumDetail.albumAssest.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionViewCell
        let asset = photoAlbumDetail.albumAssest[indexPath.row]
        
        let imageSize = CGSize(width: cell.bounds.size.width*1.5, height: cell.bounds.size.height*1.5)
        fetchImageAssetInSpecificSize(asset, targetSize: imageSize) { image in
            cell.img.image = image
        }
        return cell
    }
    
    func fetchImageAssetInSpecificSize(_ asset: PHAsset?, targetSize size: CGSize, contentMode: PHImageContentMode = .aspectFit , options: PHImageRequestOptions? = nil, completionHandler: @escaping ((_ image: UIImage) -> Void)) {
        // 1
        guard let asset = asset else {
            return
        }
        // 2
        let resultHandler: (UIImage?, [AnyHashable: Any]?) -> Void = { image, info in
            if let img = image {
                completionHandler(img)
            }
        }
        // 3
        PHImageManager.default().requestImage(
            for: asset,
            targetSize: size,
            contentMode: contentMode,
            options: options,
            resultHandler: resultHandler)
    }
    
    
}
